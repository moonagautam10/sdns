
<?php $__env->startSection('content'); ?>
<div id="page" style="margin-top: 102px;">
			<section id="pageheading">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<h3><?php echo e($page->title); ?></h3>
							<span><a href="">Home</a>/ <a href="">About us</a> / <a href=""><?php echo e($page->title); ?></a> </span>
						</div>
					</div>
				</div>
			</section>
			<section id="pagebody" style="padding: 40px 0;">	
				<div class="container">	
						<div class="row">	
								<div class="col-md-3">
									<img src="<?php echo e(asset('site/img/page/'.$page->photo)); ?>" class="img-fluid">
								</div>
								<div class="col-md-9">
									<p>	<?php echo e($page->detail); ?></p>
								</div>
						</div>
				</div>	
			</section>	
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sdns\resources\views/site/page.blade.php ENDPATH**/ ?>