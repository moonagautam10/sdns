
<?php $__env->startSection('content'); ?>
<section id="slider">
			<div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
			  	<div class="carousel-inner">
				    <div class="carousel-item active" data-interval="10000">
				      <img src="<?php echo e(asset('site/img/slider1.jpg')); ?>" class="d-block w-100" alt="...">
				    </div>
				    <div class="carousel-item" data-interval="2000">
				      <img src="<?php echo e(asset('site/img/slider2.jpg')); ?>" class="d-block w-100" alt="...">
				    </div>
				    <div class="carousel-item">
				      <img src="<?php echo e(asset('site/img/slider3.jpg')); ?>" class="d-block w-100" alt="...">
				    </div>
			  	</div>
				<a class="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
				</a>
			</div>
		</section>
		<section id="informatonbox">
			<div class="container">
				<div class="row">
					<div class="col-md-6 informationbox-left">
						<ul class="noticeboard">
							
							<h5><span style="color: red;"><i class="far fa-bell"></i></span> Notice Board</h5>
							<?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xxx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(route('getNoticeDetail',$xxx->slug)); ?>"><small style="background: red; margin-right: 10px;padding: 0 5px;"> <?php echo e($xxx->created_at->format('d M, Y')); ?></small><?php echo e($xxx->title); ?> </a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>							
						</ul>
						<p style="margin-top: 15px; text-align: right;"><a href="<?php echo e(route('getNotices')); ?>" class="btn btn-primary">View all</a></p>
					</div>
					<div class="col-md-6 informationbox-right">
						<ul class="noticeboard">
							<h5><span style="color: red;"> <i class="far fa-newspaper"></i></span> News &amp; Events</h5>
							<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(route('getNewsDetail',$abc->slug)); ?>"><small style="background: red; margin-right: 10px;padding: 0 5px;"> <?php echo e($abc->created_at->format('d M, Y')); ?></small><?php echo e($abc->title); ?> </a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</ul>
						<p style="margin-top: 15px; text-align: right;"><a href="<?php echo e(route('getNews')); ?>" class="btn btn-primary">View all</a></p>
					</div>
				</div>
			</div>
		</section>
		<section id="welcome">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<img src="<?php echo e(asset('site/img/page/'.$about->photo)); ?>" alt="" style="width: 100%">
					</div>
					<div class="col-md-8">
						<h4>Welcome to Deupur Namuna English Boarding School</h4>
						<p><?php echo e($about->detail); ?></p>
						<p style="text-align: right;"><a href="<?php echo e(route('getPage','about-us')); ?>" class="btn btn-primary">View more</a></p>
					</div>
				</div>
			</div>
		</section>
		<section id="features">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h5 class="title">Our Facilities</h5>
						<br />
							<div class="row facilities">
								<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<div class="col-md-3 col-sm-3  col-xs-6 facilities_block"> 
									<a href="">
										<img src="<?php echo e(asset('site/img/feature/'.$feature->photo)); ?>">
									</a>
									<br>
									<a href=""><?php echo e($feature->title); ?></a>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
					</div>
					<div class="col-md-4">
						<h5 class="title">Message from Chairperson</h5>
						<br />
						<p><img src="<?php echo e(asset('site/img/page/'.$chairman->photo)); ?>" alt="" style="float: left; width: 180px; margin-right: 15px;"><?php echo e($chairman->detail); ?></p>
						<p style="text-align: right;"><a href="<?php echo e(route('getPage','principle')); ?>" class="btn btn-primary">View more</a></p>
					</div>
				</div>
			</div>
		</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sdns\resources\views/site/home.blade.php ENDPATH**/ ?>