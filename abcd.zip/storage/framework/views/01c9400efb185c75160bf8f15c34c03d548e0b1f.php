 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__(' Edit Page')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div style="padding: 15px;">
                    <div class="col-md-12" style="text-align: right; padding: 20px 0;">
                        <a  href="<?php echo e(route('getManagePage')); ?>" class="btn btn-primary">Manage  Page
                        </a>
                    </div>
                            <div class="card bg-light mt-3">        
                                <div class="card-header">
                                   Edit Page
                               </div>
                                <div class="card-body"> 
                                        <form action="<?php echo e(route('postEditPage',$page->id)); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="form-group">
                                                <label class="float-left" for="title">Title</label>
                                                <input class="form-control"   value="<?php echo e($page->title); ?>"  name="title" disabled>
                                            </div>

                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Detail</label> 
                                                <textarea class="form-control" name="detail"><?php echo e($page->detail); ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Photo</label>
                                                <input type="file" class="form-control" name="photo" style="opacity:1; z-index:1;"><br/>
                                                <img src="<?php echo e(asset('site/img/page/'.$page->photo)); ?>" alt="" width="100">
                                            </div>
                                            <div class="form-group mb-0 text-center">
                                                <input class="btn btn-primary btn-block" type="submit" value="Edit"> 
                                            </div>

                                        </form>
                                </div>
                            </div>
                </div>
                   
            </div>
        </div>
    </div>

   

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\sdns\resources\views/layouts/page/edit.blade.php ENDPATH**/ ?>