
<?php $__env->startSection('content'); ?>
<div id="page" style="margin-top: 102px;">
			<section id="pageheading">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<h3>School Feature </h3>
							<span><a href="">Home</a>/ <a href="">School Feature</a> </span>
						</div>
					</div>
				</div>
			</section>
			<section id="pagebody" style="padding: 40px 0;">	
				<div class="container">	
						<div class="row">	
								<div class="col-md-8">
									<div class="row">
									<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-12" style="background: #ccc; margin-bottom: 20px; padding: 20px;">
										<h5><?php echo e($item->title); ?></h5>
										<hr>
										<p><?php echo e($item->detail); ?></p>
									</div>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								</div>
								<div class="col-md-4">
									
									<div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
									  <div class="card-header">Latest Notices</div>
									  <div class="card-body">
									   <ul style="padding: 0; margin: 0; list-style: none;">
									   	<?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									   	<li style="border-bottom: 1px solid #fff; line-height: 30px;"><a href="" style="color:#000"><?php echo e($item->title); ?></a></li>
									   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									   	
									   </ul>
									  </div>
									</div>
								</div>
						</div>
				</div>	
			</section>	
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sdns\resources\views/site/feature.blade.php ENDPATH**/ ?>